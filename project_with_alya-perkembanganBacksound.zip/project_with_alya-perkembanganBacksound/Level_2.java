import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level_2 extends World
{

    /**
     * Constructor for objects of class Level_2.
     * 
     */
    public void act()
    {    
        //menampilkan kembali objet yg telah tersentuh
        if(Greenfoot.getRandomNumber(600)<2) //angka untuk letaknya
        {
            addObject(new Boleh1(),Greenfoot.getRandomNumber(600)+0,250); //lebar //0 digunakan untuk menampilkan object dari atas //250 untuk object random
        }
        if(Greenfoot.getRandomNumber(500)<2)
        {
            addObject(new Boleh2(),Greenfoot.getRandomNumber(600)+0,89);
        }
        if(Greenfoot.getRandomNumber(700)<2)
        {
            addObject(new Boleh3(),Greenfoot.getRandomNumber(600)+0,34);
        }
        if(Greenfoot.getRandomNumber(800)<2)
        {
            addObject(new Boleh4(),Greenfoot.getRandomNumber(600)+0,87);
        }
        if(Greenfoot.getRandomNumber(500)<2)
        {
            addObject(new Boleh6(),Greenfoot.getRandomNumber(600)+0,50);
        }
        if(Greenfoot.getRandomNumber(400)<2)
        {
            addObject(new Boleh7(),Greenfoot.getRandomNumber(600)+0,67);
        }
        if(Greenfoot.getRandomNumber(700)<2)
        {
            addObject(new Boleh8(),Greenfoot.getRandomNumber(600)+0,10);
        }
        if(Greenfoot.getRandomNumber(750)<2)
        {
            addObject(new Boleh9(),Greenfoot.getRandomNumber(600)+0,40);
        }
        if(Greenfoot.getRandomNumber(100)<0) //
        {
            addObject(new Bom1(),Greenfoot.getRandomNumber(600)+0,159);
        }
        if(Greenfoot.getRandomNumber(500)<0)
        {
            addObject(new Bom2(),Greenfoot.getRandomNumber(600)+0,200);
        }
        if(Greenfoot.getRandomNumber(700)<0)
        {
            addObject(new Bom3(),Greenfoot.getRandomNumber(600)+0,250);
        }
        if(Greenfoot.getRandomNumber(800)<0)
        {
            addObject(new Bom4(),Greenfoot.getRandomNumber(600)+0,300);
        }
        
        
    }
    public Level_2()
    {    
        super(800, 500, 1); 
        Prepare();
    }
    private void Prepare()
    {
        showText("Level : 2",400,30); //menampilkan text
        panda2 panda2 = new panda2();
        addObject(panda2,67,400);
    }

}
