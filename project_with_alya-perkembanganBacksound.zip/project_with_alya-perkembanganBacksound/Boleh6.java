import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boleh6 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boleh6 extends Boleh
{
    /**
     * Act - do whatever the Boleh6 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void makan()
    {
        Actor panda2 = getOneIntersectingObject(panda2.class);
       if(panda2 != null)
       {
           getWorld().removeObject(this);
           Skor.jumlah_skor += 5;
           //Greenfoot.playSound("lagunya mana??.WAV")
       }
       else if(isAtEdge())
       {
           getWorld().removeObject(this);
       }
    }
}
