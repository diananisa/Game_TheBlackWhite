import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bom1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bom1 extends Bom
{
    /**
     * Act - do whatever the Bom1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void jatuh()
    {
       Actor panda2 = getOneIntersectingObject(panda2.class);
       if(panda2 != null)
       {
           getWorld().removeObject(this);
           Nyawa.nyawa_berkurang();
           
       }
       else if(isAtEdge())
       {
           getWorld().removeObject(this);
       }
       
    }
}
