import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boleh here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Boleh extends Actor
{
    /**
     * Act - do whatever the Boleh wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    abstract void makan();
    public void act()
    {
        //move(2);
        turn(Greenfoot.getRandomNumber(3)); //muter
        turnAtEdge();
        makan();
    
    }
    
    public void turnAtEdge()
    {
        setLocation(getX(), getY()+5);
    }
    
}
