import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    private GreenfootSound backSound = new GreenfootSound("sounds/kungfuu.mp3");
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1); 
        prepare();
    }
    
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        
        Start start = new Start();
        addObject(start,70,45);
        
        About about = new About();
        addObject(about,230,80); //230 ke samping 
        //80 kebawah
        
        How how = new How();
        addObject(how,403,110);
        
        Help help = new Help();
        addObject(help,570,80);
        
        Exit exit = new Exit();
        addObject(exit,730,45);
        
        Panda panda = new Panda();
        addObject(panda,750,320);
        //untuk angka dikoma awal makin kecil nilai maka akan ke arah start
        //untuk angka dikoma terakhir makin kecil nilai makin ke atas
    }
    
    
}
