                import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class kalah here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class kalah extends World
{

    /**
     * Constructor for objects of class kalah.
     * 
     */
    //GreenfootSound mySound = new GreenfootSound("kungfuu.mp3");
    public kalah()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1);
        addObject(new Restart(),100, 450);
        addObject(new Menu(),710, 450);
        playGameOver();
    }
    
    private void playGameOver(){
        GreenfootSound gameover = new GreenfootSound("sounds/kalah.mp3");
        gameover.play();
        gameover.setVolume(100);
    }
    
}
