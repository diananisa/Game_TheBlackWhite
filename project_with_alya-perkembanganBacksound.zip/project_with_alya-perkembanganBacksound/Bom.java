import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bom here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Bom extends Actor
{
    /**
     * Act - do whatever the Bom wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    abstract void jatuh();
    //abstract void Bom1();
    public void act()
    {
        setLocation(getX(), getY()+3); //kecepatan jatoh 8
        jatuh();
        //Bom1();
        //Bom2();
        //Bom3();
        //Bom4();
        
    }
    
    /*public void Bom1()
    {
        setLocation(getX(), getY()+8);
        jatuh();
    }
    
    public void bom2()
    {
        setLocation(getX(), getY()+5);
        jatuh();
    }
    public void bom3()
    {
        setLocation(getX(), getY()+10);
        jatuh();
    }
    public void bom4()
    {
        setLocation(getX(), getY()+3);
        jatuh();
    }*/
    
    
}
