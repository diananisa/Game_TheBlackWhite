import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class How here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class How extends Actor
{ 
    /**
     * Act - do whatever the How wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        GreenfootImage image = new GreenfootImage("How to play(1).png");
        setImage(image);
        
        if(Greenfoot.mousePressed(this))
        {
            Greenfoot.setWorld(new About_1());
        }
    }
}
