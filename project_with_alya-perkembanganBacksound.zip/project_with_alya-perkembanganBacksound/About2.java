import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class About2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class About2 extends World
{

    /**
     * Constructor for objects of class About2.
     * 
     */
    public About2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1); //ukuran layar 
        addObject(new Back(),100,435); //button back dan letaknya
        //addObject(new Next(),700,435);
        
        tuliasn_about2 tuliasn_about2 = new tuliasn_about2();
        addObject(tuliasn_about2,400,250); 
        
        Panda panda = new Panda();
        addObject(panda,750,320); //panda dan letaknya
    }
}
