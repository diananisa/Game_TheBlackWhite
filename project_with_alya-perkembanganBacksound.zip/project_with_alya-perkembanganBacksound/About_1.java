import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class About_1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class About_1 extends World
{

    /**
     * Constructor for objects of class About_1.
     * 
     */
    public About_1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1);
        addObject(new Back(),100,435);
        addObject(new Next(),700,435);
        
        tulisan_about1 tulisan_about1 = new tulisan_about1();
        addObject(tulisan_about1,400,250);
        
        Panda panda = new Panda();
        addObject(panda,750,280);
    }
}
