import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class panda2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class panda2 extends Actor
{
    /**
     * Act - do whatever the panda2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //private int speed = 2;
    public void act()
    {
        
        gerak();
        getWorld().showText("Skore : " + Skor.jumlah_skor, 85, 30);
        getWorld().showText("Nyawa : " + Nyawa.jumlah_nyawa, 750, 30);
        
        
        cek_level();
    }
    
    
    
    
    public void cek_level()
    {
        if(Skor.jumlah_skor == 150 || Skor.jumlah_skor > 150)
        {
            Greenfoot.setWorld(new Menang());
        }
        else if(Skor.jumlah_skor == 100)
        {
            Skor.jumlah_skor++;
            Greenfoot.setWorld(new Level_2());
        }
        
    }
    
    public void gerak()
    {
        if(Greenfoot.isKeyDown("up")){
            setLocation(getX(), getY() + -2); //ke atas
        }
        if(Greenfoot.isKeyDown("down")){
            setLocation(getX(), getY() + 2);
        }
        if(Greenfoot.isKeyDown("left")){
            move(-4);
        }
        if(Greenfoot.isKeyDown("right")){
            move(4);
        }
    }
}
