import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menang here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menang extends World
{

    /**
     * Constructor for objects of class Menang.
     * 
     */
    
    
    public Menang()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1); 
        addObject(new Restart(), 100,60);
        addObject(new Menu(), 710,60);
        playApplause();
        //mySound.play();
        
    }
    
    private void playApplause(){
        GreenfootSound applause = new GreenfootSound("sounds/menang.mp3");
        applause.play();
        applause.setVolume(100);
    }
    
}
