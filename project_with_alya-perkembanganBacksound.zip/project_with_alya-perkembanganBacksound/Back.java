import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Back here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Back extends Actor
{
    /**
     * Act - do whatever the Back wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        GreenfootImage image = new GreenfootImage("Back(1).png");
        setImage(image);
        
        if(Greenfoot.mousePressed(this))
        {
            Greenfoot.setWorld(new MyWorld()); //jika klik back maka akan ke tempat awal yaitu MyWord
            //Greenfoot.setWorld(new About2());
            //Greenfoot.setWorld(new Aturan());
        }
    }
}
