import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Next here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Next extends Actor
{
    /**
     * Act - do whatever the Next wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        GreenfootImage image = new GreenfootImage("Next(1).png"); //setting gambar yang ada di dalam folder
        setImage(image);
        
        if(Greenfoot.mousePressed(this))
        {
            Greenfoot.setWorld(new About2()); //jika klik next maka akan ke About2
        }
    }
}
