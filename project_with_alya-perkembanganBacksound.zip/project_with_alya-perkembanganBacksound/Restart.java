import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Restart here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Restart extends Actor
{
    /**
     * Act - do whatever the Restart wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(Greenfoot.mouseClicked(this))
        {
            Nyawa.jumlah_nyawa = 3;
            Skor.jumlah_skor = 0;
            Greenfoot.delay(2);
                Greenfoot.setWorld(new Level_1());
        }
        if(Greenfoot.mouseClicked(this))
        {
            getImage().scale((int)Math.round(getImage().getWidth()*0.9),
            (int)Math.round(getImage().getHeight()*0.9));
        }
        
        /*GreenfootImage image = new GreenfootImage("restart(1.3).png");
        setImage(image);
        
        if(Greenfoot.mousePressed(this))
        {
            Greenfoot.setWorld(new Level_1());
        }*/
    }
}
