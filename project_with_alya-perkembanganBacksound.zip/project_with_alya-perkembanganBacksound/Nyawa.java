import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nyawa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nyawa extends World
{
    static int jumlah_nyawa = 5;
    /**
     * Constructor for objects of class Nyawa.
     * 
     */
    public Nyawa()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1);
    }
    public static void nyawa_berkurang()
    {
        jumlah_nyawa--;
        if(jumlah_nyawa <= 0)
        {
            Greenfoot.setWorld(new kalah());
        }
    }
}
